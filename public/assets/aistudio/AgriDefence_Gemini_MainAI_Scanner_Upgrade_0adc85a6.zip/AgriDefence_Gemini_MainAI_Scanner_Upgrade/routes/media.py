import os

from flask import Blueprint, abort, current_app, send_from_directory

from models.database import get_db
from utils.security import current_user_id

media_bp = Blueprint('media', __name__)


def _send_owned_image(image_path):
    if not image_path:
        abort(404)

    normalized = image_path.replace('\\', '/').lstrip('/')
    locations = {
        'private_uploads/scans/': os.path.join(current_app.root_path, 'private_uploads', 'scans'),
        'private_uploads/plants/': os.path.join(current_app.root_path, 'private_uploads', 'plants'),
        'uploads/scans/': os.path.join(current_app.root_path, 'static', 'uploads', 'scans'),
        'uploads/plants/': os.path.join(current_app.root_path, 'static', 'uploads', 'plants')
    }
    for prefix, directory in locations.items():
        if normalized.startswith(prefix):
            filename = normalized[len(prefix):]
            if filename and filename == os.path.basename(filename):
                return send_from_directory(directory, filename, conditional=True, max_age=0)
    abort(404)


@media_bp.route('/media/scan/<int:scan_id>')
def scan(scan_id):
    db = get_db()
    row = db.execute(
        'SELECT image_path FROM scans WHERE id = ? AND user_id = ?',
        (scan_id, current_user_id())
    ).fetchone()
    db.close()
    if not row:
        abort(404)
    return _send_owned_image(row['image_path'])


@media_bp.route('/media/plant/<int:plant_id>')
def plant(plant_id):
    db = get_db()
    row = db.execute(
        'SELECT image_path FROM plants WHERE id = ? AND user_id = ?',
        (plant_id, current_user_id())
    ).fetchone()
    db.close()
    if not row:
        abort(404)
    return _send_owned_image(row['image_path'])
