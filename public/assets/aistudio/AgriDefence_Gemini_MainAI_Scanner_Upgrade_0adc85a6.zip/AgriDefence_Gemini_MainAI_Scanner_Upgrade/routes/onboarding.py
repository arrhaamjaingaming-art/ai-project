from flask import Blueprint, flash, redirect, render_template, request, session, url_for

from models.database import get_db
from routes.settings_route import LANGUAGES
from utils.security import current_user_id

onboarding_bp = Blueprint('onboarding', __name__)


@onboarding_bp.route('/onboarding', methods=['GET', 'POST'])
def index():
    user_id = current_user_id()
    db = get_db()
    user = db.execute(
        'SELECT onboarding_completed, user_mode, language, theme FROM users WHERE id = ?',
        (user_id,)
    ).fetchone()
    if not user:
        db.close()
        return redirect(url_for('auth.login'))

    if request.method == 'GET' and user['onboarding_completed']:
        db.close()
        return redirect(url_for('dashboard.index'))

    if request.method == 'POST':
        user_mode = request.form.get('user_mode', 'farmer')
        language = request.form.get('language', 'en')
        if user_mode not in ('farmer', 'gardener'):
            user_mode = 'farmer'
        if language not in {item['code'] for item in LANGUAGES}:
            language = 'en'
        db.execute(
            """UPDATE users
               SET user_mode = ?, language = ?, onboarding_completed = 1
               WHERE id = ?""",
            (user_mode, language, user_id)
        )
        db.commit()
        db.close()
        session['user_mode'] = user_mode
        session['language'] = language
        session['theme'] = user['theme'] or 'light'
        flash('Your Agri Defence workspace is ready.', 'success')
        return redirect(url_for('dashboard.index'))

    db.close()
    return render_template(
        'onboarding.html',
        active_page='onboarding',
        languages=LANGUAGES,
        selected_mode=user['user_mode'] or 'farmer',
        selected_language=user['language'] or 'en'
    )
