from datetime import date
from flask import Blueprint, render_template
from models.database import get_db
from utils.security import current_user_id

dashboard_bp = Blueprint('dashboard', __name__)


@dashboard_bp.route('/dashboard')
def index():
    user_id = current_user_id()
    db = get_db()

    total_plants = db.execute(
        'SELECT COUNT(*) as c FROM plants WHERE user_id = ?', (user_id,)
    ).fetchone()['c']

    total_scans = db.execute(
        'SELECT COUNT(*) as c FROM scans WHERE user_id = ?', (user_id,)
    ).fetchone()['c']

    diseases_found = db.execute(
        'SELECT COUNT(*) as c FROM scans WHERE user_id = ? AND is_healthy = 0', (user_id,)
    ).fetchone()['c']

    healthy_plants = db.execute(
        "SELECT COUNT(*) as c FROM plants WHERE user_id = ? AND health_status = 'healthy'",
        (user_id,)
    ).fetchone()['c']

    recent_activities = db.execute(
        'SELECT * FROM activities WHERE user_id = ? ORDER BY created_at DESC LIMIT 8',
        (user_id,)
    ).fetchall()

    upcoming_reminders = db.execute(
        """SELECT r.*, p.name as plant_name FROM reminders r
           LEFT JOIN plants p ON r.plant_id = p.id
           WHERE r.user_id = ? AND r.is_completed = 0
           ORDER BY r.reminder_date ASC LIMIT 4""",
        (user_id,)
    ).fetchall()

    recent_scans = db.execute(
        'SELECT * FROM scans WHERE user_id = ? ORDER BY created_at DESC LIMIT 5',
        (user_id,)
    ).fetchall()

    plant_health_data = db.execute(
        """SELECT health_status, COUNT(*) as count
           FROM plants WHERE user_id = ?
           GROUP BY health_status""",
        (user_id,)
    ).fetchall()

    weekly_scans = []
    for i in range(7, 0, -1):
        count = db.execute(
            """SELECT COUNT(*) as c FROM scans
               WHERE user_id = ? AND date(created_at) = date('now', ? || ' days')""",
            (user_id, f'-{i-1}')
        ).fetchone()['c']
        weekly_scans.append(count)

    user = db.execute(
        'SELECT user_mode FROM users WHERE id = ?', (user_id,)
    ).fetchone()
    user_mode = user['user_mode'] if user and user['user_mode'] else 'farmer'
    db.close()

    stats = {
        'total_plants': total_plants,
        'total_scans': total_scans,
        'diseases_found': diseases_found,
        'healthy_plants': healthy_plants,
    }

    health_labels = []
    health_values = []
    health_colors = []
    color_map = {
        'healthy': '#4CAF50',
        'diseased': '#F44336',
        'recovering': '#FF9800',
        'unknown': '#9E9E9E',
    }
    for row in plant_health_data:
        health_labels.append(row['health_status'].capitalize())
        health_values.append(row['count'])
        health_colors.append(color_map.get(row['health_status'], '#9E9E9E'))

    farming_tips = [
        {"icon": "fa-tint", "tip": "Water plants early morning to reduce evaporation and fungal risk."},
        {"icon": "fa-sun", "tip": "Rotate crops annually to prevent soil-borne disease buildup."},
        {"icon": "fa-leaf", "tip": "Apply mulch around plants to retain moisture and suppress weeds."},
        {"icon": "fa-flask", "tip": "Test soil pH regularly — most crops thrive between 6.0–7.0."},
        {"icon": "fa-bug", "tip": "Introduce beneficial insects like ladybugs to control aphid populations."},
    ]

    tip_of_day = farming_tips[date.today().toordinal() % len(farming_tips)]

    return render_template('dashboard.html',
        active_page='dashboard',
        stats=stats,
        recent_activities=recent_activities,
        upcoming_reminders=upcoming_reminders,
        recent_scans=recent_scans,
        health_labels=health_labels,
        health_values=health_values,
        health_colors=health_colors,
        weekly_scans=weekly_scans,
        farming_tips=farming_tips,
        tip_of_day=tip_of_day,
        user_mode=user_mode,
    )
