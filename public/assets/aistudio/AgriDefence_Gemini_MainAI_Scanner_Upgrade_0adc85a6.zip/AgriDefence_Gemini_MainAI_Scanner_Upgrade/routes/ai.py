import os
import uuid

from flask import Blueprint, current_app, jsonify, render_template, request

from ai.chatbot import AgriChatbot

ai_bp = Blueprint('ai', __name__, url_prefix='/ai')
ALLOWED_IMAGE_EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp'}


@ai_bp.route('/chat')
def chat():
    return render_template(
        'chat.html',
        active_page='chat',
        gemini_available=bool(os.environ.get('GEMINI_API_KEY'))
    )


@ai_bp.route('/ask')
def ask_ai():
    return render_template(
        'ask_ai.html',
        active_page='ask_ai',
        gemini_available=bool(os.environ.get('GEMINI_API_KEY'))
    )


@ai_bp.route('/api/chat', methods=['POST'])
def chat_api():
    data = request.get_json(silent=True) or {}
    message = str(data.get('message', '')).strip()
    if not message:
        return jsonify({'success': False, 'error': 'Please enter a question.'}), 400
    if len(message) > 2000:
        return jsonify({'success': False, 'error': 'Keep your question under 2,000 characters.'}), 400

    try:
        result = AgriChatbot().ask(message)
        if not result.get('success'):
            return jsonify({
                'success': False,
                'error': result.get('error', 'Agri Defence could not respond.')
            }), 503
        return jsonify({
            'success': True,
            'answer': result.get('text', ''),
            'mode': result.get('mode', 'gemini' if os.environ.get('GEMINI_API_KEY') else 'basic')
        })
    except Exception:
        current_app.logger.exception('AI chat request failed')
        return jsonify({
            'success': False,
            'error': 'Agri Defence could not respond. Please try again.'
        }), 500


@ai_bp.route('/api/analyze', methods=['POST'])
def analyze():
    if not os.environ.get('GEMINI_API_KEY'):
        return jsonify({
            'success': False,
            'error': (
                'Gemini is not configured, so this image was not diagnosed. '
                'Add GEMINI_API_KEY to enable image analysis.'
            )
        }), 503

    image = request.files.get('image')
    if not image or not image.filename:
        return jsonify({'success': False, 'error': 'Please upload a plant image.'}), 400

    extension = image.filename.rsplit('.', 1)[-1].lower() if '.' in image.filename else ''
    if extension not in ALLOWED_IMAGE_EXTENSIONS:
        return jsonify({'success': False, 'error': 'Use JPG, JPEG, PNG, or WEBP.'}), 400

    question = request.form.get('question', '').strip()[:2000]
    upload_dir = os.path.join(current_app.root_path, 'private_uploads', 'temporary')
    os.makedirs(upload_dir, exist_ok=True)
    image_path = os.path.join(upload_dir, '{}.{}'.format(uuid.uuid4().hex, extension))

    try:
        image.save(image_path)
        result = AgriChatbot().analyze_image(image_path, question)
        if not result.get('success'):
            return jsonify({
                'success': False,
                'error': result.get('error', 'The image could not be analyzed.')
            }), 503
        return jsonify({
            'success': True,
            'answer': result.get('text', ''),
            'mode': 'gemini'
        })
    except Exception:
        current_app.logger.exception('AI image request failed')
        return jsonify({
            'success': False,
            'error': 'The image could not be analyzed. Please try again.'
        }), 500
    finally:
        try:
            os.remove(image_path)
        except OSError:
            pass
