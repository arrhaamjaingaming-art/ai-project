import datetime
from flask import Blueprint, render_template
from models.database import get_db
from utils.security import current_user_id

reports_bp = Blueprint('reports', __name__)


@reports_bp.route('/reports')
def index():
    user_id = current_user_id()
    db = get_db()

    # Weekly scan counts (last 7 days)
    weekly_data = []
    weekly_labels = []
    today = datetime.date.today()
    for i in range(6, -1, -1):
        row = db.execute(
            "SELECT COUNT(*) as c FROM scans WHERE user_id = ? AND date(created_at) = date('now', ? || ' days')",
            (user_id, f'-{i}')
        ).fetchone()
        weekly_data.append(row['c'])
        d = today - datetime.timedelta(days=i)
        weekly_labels.append(d.strftime('%a %d'))

    # Disease distribution
    disease_rows = db.execute(
        """SELECT disease_name, COUNT(*) as count FROM scans
           WHERE user_id = ? AND is_healthy = 0 AND disease_name IS NOT NULL
           GROUP BY disease_name ORDER BY count DESC LIMIT 8""",
        (user_id,)
    ).fetchall()
    disease_labels = [r['disease_name'] for r in disease_rows]
    disease_counts = [r['count'] for r in disease_rows]

    # Healthy vs diseased
    total_scans = db.execute('SELECT COUNT(*) as c FROM scans WHERE user_id = ?', (user_id,)).fetchone()['c']
    healthy_scans = db.execute('SELECT COUNT(*) as c FROM scans WHERE user_id = ? AND is_healthy = 1', (user_id,)).fetchone()['c']
    diseased_scans = total_scans - healthy_scans

    # Monthly summary
    monthly_rows = db.execute(
        """SELECT strftime('%Y-%m', created_at) as month, COUNT(*) as total,
           SUM(is_healthy) as healthy_count
           FROM scans WHERE user_id = ?
           GROUP BY month ORDER BY month DESC LIMIT 6""",
        (user_id,)
    ).fetchall()

    # Top diseases overall
    top_diseases = db.execute(
        """SELECT disease_name, disease_key, COUNT(*) as count,
           AVG(confidence) as avg_confidence
           FROM scans WHERE user_id = ? AND is_healthy = 0
           GROUP BY disease_name ORDER BY count DESC LIMIT 5""",
        (user_id,)
    ).fetchall()

    # Severity breakdown
    severity_rows = db.execute(
        """SELECT severity, COUNT(*) as count FROM scans
           WHERE user_id = ? AND severity IS NOT NULL
           GROUP BY severity""",
        (user_id,)
    ).fetchall()
    severity_data = {r['severity']: r['count'] for r in severity_rows}

    db.close()

    stats = {
        'total_scans': total_scans,
        'healthy_scans': healthy_scans,
        'diseased_scans': diseased_scans,
        'health_rate': round((healthy_scans / total_scans * 100) if total_scans > 0 else 0, 1),
    }

    return render_template('reports.html',
        active_page='reports',
        stats=stats,
        weekly_labels=weekly_labels,
        weekly_data=weekly_data,
        disease_labels=disease_labels,
        disease_counts=disease_counts,
        monthly_rows=monthly_rows,
        top_diseases=top_diseases,
        severity_data=severity_data,
        healthy_diseased=[healthy_scans, diseased_scans],
    )
