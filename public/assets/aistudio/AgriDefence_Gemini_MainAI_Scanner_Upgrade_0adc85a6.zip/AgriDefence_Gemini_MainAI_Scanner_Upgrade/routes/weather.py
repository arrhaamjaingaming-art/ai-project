from datetime import datetime, timezone

import requests
from flask import Blueprint, render_template, request

from models.database import get_db
from utils.security import current_user_id

weather_bp = Blueprint('weather', __name__)

WEATHER_CODES = {
    0: 'Clear sky', 1: 'Mostly clear', 2: 'Partly cloudy', 3: 'Overcast',
    45: 'Fog', 48: 'Depositing rime fog',
    51: 'Light drizzle', 53: 'Moderate drizzle', 55: 'Dense drizzle',
    61: 'Slight rain', 63: 'Moderate rain', 65: 'Heavy rain',
    71: 'Slight snow', 73: 'Moderate snow', 75: 'Heavy snow',
    80: 'Rain showers', 81: 'Moderate rain showers', 82: 'Violent rain showers',
    95: 'Thunderstorm', 96: 'Thunderstorm with hail', 99: 'Thunderstorm with hail'
}


def _coordinates_for_location(location):
    response = requests.get(
        'https://geocoding-api.open-meteo.com/v1/search',
        params={'name': location, 'count': 1, 'language': 'en', 'format': 'json'},
        timeout=8
    )
    response.raise_for_status()
    results = response.json().get('results') or []
    if not results:
        return None
    place = results[0]
    label = ', '.join(
        part for part in (place.get('name'), place.get('admin1'), place.get('country'))
        if part
    )
    return float(place['latitude']), float(place['longitude']), label


def _weather_for_coordinates(latitude, longitude, label):
    response = requests.get(
        'https://api.open-meteo.com/v1/forecast',
        params={
            'latitude': latitude,
            'longitude': longitude,
            'current': 'temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m',
            'daily': 'weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max',
            'forecast_days': 3,
            'timezone': 'auto'
        },
        timeout=8
    )
    response.raise_for_status()
    data = response.json()
    current = data.get('current')
    daily = data.get('daily')
    if not isinstance(current, dict) or not isinstance(daily, dict):
        return None

    forecast = []
    dates = daily.get('time', [])
    codes = daily.get('weather_code', [])
    highs = daily.get('temperature_2m_max', [])
    lows = daily.get('temperature_2m_min', [])
    rain = daily.get('precipitation_probability_max', [])
    for index, day in enumerate(dates):
        if index >= min(len(codes), len(highs), len(lows)):
            break
        forecast.append({
            'date': day,
            'condition': WEATHER_CODES.get(codes[index], 'Conditions unavailable'),
            'high': highs[index],
            'low': lows[index],
            'rain_chance': rain[index] if index < len(rain) else None
        })
    return {
        'location': label,
        'temperature': current.get('temperature_2m'),
        'humidity': current.get('relative_humidity_2m'),
        'precipitation': current.get('precipitation'),
        'wind': current.get('wind_speed_10m'),
        'condition': WEATHER_CODES.get(current.get('weather_code'), 'Conditions unavailable'),
        'forecast': forecast,
        'retrieved_at': datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')
    }


@weather_bp.route('/weather', methods=['GET', 'POST'])
def index():
    user_id = current_user_id()
    db = get_db()
    user = db.execute('SELECT location FROM users WHERE id = ?', (user_id,)).fetchone()
    saved_location = user['location'] if user and user['location'] else ''

    location = request.values.get('location', '').strip()[:100]
    latitude = request.values.get('latitude', '').strip()
    longitude = request.values.get('longitude', '').strip()

    if request.method == 'POST' and location:
        db.execute('UPDATE users SET location = ? WHERE id = ?', (location, user_id))
        db.commit()
        saved_location = location
    db.close()

    report = None
    error = None
    selected_location = location or saved_location
    try:
        if latitude or longitude:
            lat = float(latitude)
            lon = float(longitude)
            if not (-90 <= lat <= 90 and -180 <= lon <= 180):
                raise ValueError('Choose a valid location.')
            report = _weather_for_coordinates(lat, lon, 'Selected map location')
            selected_location = ''
        elif selected_location:
            coords = _coordinates_for_location(selected_location)
            if not coords:
                error = 'No matching location was found. Check the spelling and try again.'
            else:
                report = _weather_for_coordinates(coords[0], coords[1], coords[2])
                if not report:
                    error = 'The weather service returned incomplete data.'
        else:
            error = 'Enter a town or district, or allow location access to request weather.'
    except ValueError as exc:
        error = str(exc)
    except requests.RequestException:
        error = 'Weather is unavailable right now. Check your connection and try again.'
    except (KeyError, TypeError):
        error = 'The weather service returned incomplete data.'

    return render_template(
        'weather.html',
        active_page='weather',
        report=report,
        error=error,
        location=selected_location
    )
