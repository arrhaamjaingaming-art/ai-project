import os
from flask import Blueprint, render_template, request, jsonify, current_app, url_for
from models.database import get_db
from utils.helpers import save_image
from ai.chatbot import AgriChatbot
from utils.security import current_user_id

scanner_bp = Blueprint('scanner', __name__)


@scanner_bp.route('/scanner')
def index():
    user_id = current_user_id()
    db = get_db()
    plants = db.execute(
        'SELECT id, name FROM plants WHERE user_id = ? ORDER BY name ASC',
        (user_id,)
    ).fetchall()
    db.close()
    return render_template(
        'scanner.html',
        active_page='scanner',
        plants=plants,
        gemini_available=bool(os.environ.get('GEMINI_API_KEY'))
    )


@scanner_bp.route('/scanner/analyze', methods=['POST'])
def analyze():
    user_id = current_user_id()

    if 'image' not in request.files:
        return jsonify({
            'success': False,
            'error': 'No image provided.'
        }), 400

    file = request.files['image']

    if file.filename == '':
        return jsonify({
            'success': False,
            'error': 'No file selected.'
        }), 400

    plant_id = request.form.get('plant_id') or None
    plant_name = request.form.get(
        'plant_name',
        'Unknown Plant'
    ).strip() or 'Unknown Plant'

    question = request.form.get(
        'question',
        ''
    ).strip()

    if plant_id:
        try:
            plant_id = int(plant_id)
        except (TypeError, ValueError):
            return jsonify({'success': False, 'error': 'Choose a valid plant or leave this field blank.'}), 400
        db = get_db()
        plant = db.execute(
            'SELECT name FROM plants WHERE id = ? AND user_id = ?',
            (plant_id, user_id)
        ).fetchone()
        db.close()
        if not plant:
            return jsonify({'success': False, 'error': 'That plant is not available in your records.'}), 404
        plant_name = plant['name']

    ai = AgriChatbot()
    if not ai.is_available:
        return jsonify({
            'success': False,
            'error': (
                'Gemini is not configured, so the image was not diagnosed or saved. '
                'Set GEMINI_API_KEY to enable image scanning; basic chat guidance remains available.'
            )
        }), 503

    upload_dir = os.path.join(current_app.root_path, 'private_uploads', 'scans')

    filename = save_image(file, upload_dir)

    if not filename:
        return jsonify({
            'success': False,
            'error': 'Invalid file type. Please upload an image.'
        }), 400

    full_image_path = os.path.join(upload_dir, filename)
    image_path = f'private_uploads/scans/{filename}'

    try:
        result = ai.analyze_image_structured(
            full_image_path,
            question=question
        )

        if not result.get('success'):
            try:
                os.remove(full_image_path)
            except OSError:
                pass
            return jsonify({
                'success': False,
                'error': result.get('error', 'The image could not be analyzed.')
            }), 503

        # ========================================================
        # SAVE SCAN
        # ========================================================
        db = get_db()

        cur = db.execute(
            """INSERT INTO scans
               (user_id, plant_id, plant_name, image_path,
                disease_name, disease_key, confidence, severity,
                treatment, prevention, description, is_healthy)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                user_id,
                plant_id,
                plant_name,
                image_path,
                result['name'],
                result['key'],
                result['confidence'],
                result['severity'],
                result['treatment'],
                result['prevention'],
                result['description'],
                result['is_healthy']
            )
        )

        scan_id = cur.lastrowid

        # Update selected plant health status.
        if plant_id:
            status = (
                'healthy'
                if result['is_healthy']
                else 'diseased'
            )

            db.execute(
                'UPDATE plants SET health_status = ? '
                'WHERE id = ? AND user_id = ?',
                (status, plant_id, user_id)
            )

        # ========================================================
        # ACTIVITY LOG
        # ========================================================
        if result['is_healthy']:
            icon = 'fa-check-circle'
            color = 'green'
            desc = (
                'Plant appears healthy — '
                f"{result['confidence']}% AI assessment"
            )
        else:
            icon = 'fa-virus'
            color = 'red'
            desc = (
                f"AI assessment: {result['name']} "
                f"({result['confidence']}%)"
            )

        db.execute(
            'INSERT INTO activities '
            '(user_id, action, description, icon, color) '
            'VALUES (?, ?, ?, ?, ?)',
            (
                user_id,
                f'Scan completed for {plant_name}',
                desc,
                icon,
                color
            )
        )

        db.commit()
        db.close()

        return jsonify({
            'success': True,
            'scan_id': scan_id,
            'image_path': image_path,
            'image_url': url_for('media.scan', scan_id=scan_id),
            'disease_name': result['name'],
            'disease_key': result['key'],
            'confidence': result['confidence'],
            'severity': result['severity'],
            'treatment': result['treatment'],
            'prevention': result['prevention'],
            'description': result['description'],
            'is_healthy': result['is_healthy'],
            'alternatives': result.get('alternatives', []),
            'image_signals': result.get('image_signals', []),
            'affected_parts': result.get('affected_parts', ''),
            'symptoms': result.get('symptoms', '')
        })

    except ValueError as error:
        try:
            os.remove(full_image_path)
        except OSError:
            pass
        return jsonify({
            'success': False,
            'error': str(error)
        }), 400

    except Exception as error:
        try:
            os.remove(full_image_path)
        except OSError:
            pass
        current_app.logger.exception('Plant scan failed')
        return jsonify({
            'success': False,
            'error': 'Could not complete the scan. Please try again.'
        }), 500


@scanner_bp.route('/scanner/result/<int:scan_id>')
def result(scan_id):
    user_id = current_user_id()
    db = get_db()
    scan = db.execute(
        'SELECT * FROM scans WHERE id = ? AND user_id = ?',
        (scan_id, user_id)
    ).fetchone()
    db.close()

    if not scan:
        from flask import abort
        abort(404)

    return render_template(
        'scanner_result.html',
        scan=scan,
        active_page='scanner'
    )
