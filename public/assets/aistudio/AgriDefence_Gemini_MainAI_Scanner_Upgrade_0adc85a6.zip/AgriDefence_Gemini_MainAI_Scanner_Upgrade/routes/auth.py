import re
from urllib.parse import urlsplit

from flask import Blueprint, flash, redirect, render_template, request, session, url_for
from werkzeug.security import check_password_hash, generate_password_hash

from models.database import get_db, GUEST_USER_ID

auth_bp = Blueprint('auth', __name__)

USERNAME_PATTERN = re.compile(r'^[A-Za-z0-9_.-]{3,32}$')
EMAIL_PATTERN = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def _safe_next():
    target = request.form.get('next') or request.args.get('next', '')
    parsed = urlsplit(target)
    if target.startswith('/') and not target.startswith('//') and not parsed.netloc:
        return target
    return url_for('dashboard.index')


def _set_user_session(user):
    session.clear()
    session.permanent = True
    session['user_id'] = user['id']
    session['username'] = user['username']
    session['full_name'] = user['full_name'] or user['username']
    session['email'] = user['email']
    session['theme'] = user['theme'] or 'light'
    session['language'] = user['language'] or 'en'
    session['user_mode'] = user['user_mode'] or 'farmer'


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        identity = request.form.get('identity', '').strip().lower()
        password = request.form.get('password', '')
        if not identity or not password:
            flash('Enter your email or username and password.', 'error')
            return render_template('login.html', next_url=_safe_next()), 400

        db = get_db()
        try:
            user = db.execute(
                'SELECT * FROM users WHERE lower(email) = ? OR lower(username) = ?',
                (identity, identity)
            ).fetchone()
        finally:
            db.close()

        valid_password = False
        if user and user['id'] != GUEST_USER_ID:
            try:
                valid_password = check_password_hash(user['password'], password)
            except (TypeError, ValueError):
                valid_password = False

        if not valid_password:
            flash('Those sign-in details were not recognized.', 'error')
            return render_template('login.html', next_url=_safe_next()), 401

        _set_user_session(user)
        if not user['onboarding_completed']:
            return redirect(url_for('onboarding.index'))
        flash('Welcome back, {}.'.format(user['full_name'] or user['username']), 'success')
        return redirect(_safe_next())

    return render_template('login.html', next_url=_safe_next())


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form.get('full_name', '').strip()
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')

        error = None
        if not full_name:
            error = 'Enter your name.'
        elif not USERNAME_PATTERN.fullmatch(username):
            error = 'Username must be 3–32 characters using letters, numbers, dots, dashes, or underscores.'
        elif not EMAIL_PATTERN.fullmatch(email):
            error = 'Enter a valid email address.'
        elif len(password) < 8:
            error = 'Use a password with at least 8 characters.'
        elif password != confirm_password:
            error = 'The passwords do not match.'

        if error:
            flash(error, 'error')
            return render_template('register.html'), 400

        db = get_db()
        try:
            cursor = db.execute(
                """INSERT INTO users (username, email, password, full_name)
                   VALUES (?, ?, ?, ?)""",
                (
                    username,
                    email,
                    generate_password_hash(password, method='pbkdf2:sha256:600000'),
                    full_name
                )
            )
            db.commit()
            user = db.execute(
                'SELECT * FROM users WHERE id = ?', (cursor.lastrowid,)
            ).fetchone()
        except Exception as error:
            db.rollback()
            if 'UNIQUE constraint failed' in str(error):
                flash('That username or email is already registered.', 'error')
                return render_template('register.html'), 409
            raise
        finally:
            db.close()

        _set_user_session(user)
        flash('Your account is ready. Choose how you want to use Agri Defence.', 'success')
        return redirect(url_for('onboarding.index'))

    return render_template('register.html')


@auth_bp.route('/logout', methods=['POST'])
def logout():
    session.clear()
    flash('You have been signed out. You can continue in guest mode.', 'info')
    return redirect(url_for('dashboard.index'))
