import os
import sys
import sqlite3
import platform
import datetime
import re
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, session
from werkzeug.security import check_password_hash, generate_password_hash
from models.database import get_db, DB_PATH, GUEST_USER_ID
from utils.security import current_user_id

settings_bp = Blueprint('settings', __name__)

LANGUAGES = [
    {'code': 'en', 'name': 'English'},
    {'code': 'hi', 'name': 'Hindi'},
    {'code': 'ta', 'name': 'Tamil'},
    {'code': 'te', 'name': 'Telugu'},
    {'code': 'bn', 'name': 'Bengali'},
    {'code': 'mr', 'name': 'Marathi'},
    {'code': 'kn', 'name': 'Kannada'},
    {'code': 'ml', 'name': 'Malayalam'},
    {'code': 'gu', 'name': 'Gujarati'},
    {'code': 'pa', 'name': 'Punjabi'},
    {'code': 'or', 'name': 'Odia'},
    {'code': 'ur', 'name': 'Urdu'},
]

APP_VERSION = '3.1.0'
APP_RELEASE_DATE = 'October 2026'


def _folder_size_mb(path):
    """Return folder size in MB, or 0 if folder doesn't exist."""
    total = 0
    if os.path.isdir(path):
        for dirpath, _, filenames in os.walk(path):
            for f in filenames:
                fp = os.path.join(dirpath, f)
                try:
                    total += os.path.getsize(fp)
                except OSError:
                    pass
    return round(total / (1024 * 1024), 2)


def _count_files(path):
    count = 0
    if os.path.isdir(path):
        for _, _, filenames in os.walk(path):
            count += len(filenames)
    return count


def get_system_info(user_id):
    """Gather DB stats, storage usage, and system information."""
    db = get_db()

    total_plants  = db.execute('SELECT COUNT(*) as c FROM plants WHERE user_id = ?', (user_id,)).fetchone()['c']
    total_scans   = db.execute('SELECT COUNT(*) as c FROM scans WHERE user_id = ?', (user_id,)).fetchone()['c']
    total_acts    = db.execute('SELECT COUNT(*) as c FROM activities WHERE user_id = ?', (user_id,)).fetchone()['c']
    healthy_scans = db.execute('SELECT COUNT(*) as c FROM scans WHERE user_id = ? AND is_healthy = 1', (user_id,)).fetchone()['c']
    disease_scans = total_scans - healthy_scans
    image_paths = [
        row['image_path']
        for row in db.execute(
            'SELECT image_path FROM scans WHERE user_id = ? AND image_path IS NOT NULL '
            'UNION ALL SELECT image_path FROM plants WHERE user_id = ? AND image_path IS NOT NULL',
            (user_id, user_id)
        ).fetchall()
    ]
    db.close()

    db_size_kb = 0
    db_status = 'Online'
    if os.path.exists(DB_PATH):
        db_size_kb = round(os.path.getsize(DB_PATH) / 1024, 1)
    else:
        db_status = 'Not initialised'

    app_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    uploads_bytes = 0
    uploads_files = 0
    for image_path in image_paths:
        normalized = str(image_path).replace('\\', '/').lstrip('/')
        if normalized.startswith('private_uploads/scans/'):
            folder = os.path.join(app_root, 'private_uploads', 'scans')
            filename = normalized[len('private_uploads/scans/'):]
        elif normalized.startswith('private_uploads/plants/'):
            folder = os.path.join(app_root, 'private_uploads', 'plants')
            filename = normalized[len('private_uploads/plants/'):]
        elif normalized.startswith('uploads/scans/'):
            folder = os.path.join(app_root, 'static', 'uploads', 'scans')
            filename = normalized[len('uploads/scans/'):]
        elif normalized.startswith('uploads/plants/'):
            folder = os.path.join(app_root, 'static', 'uploads', 'plants')
            filename = normalized[len('uploads/plants/'):]
        else:
            continue
        if filename and filename == os.path.basename(filename):
            filepath = os.path.join(folder, filename)
            try:
                uploads_bytes += os.path.getsize(filepath)
                uploads_files += 1
            except OSError:
                pass
    uploads_mb = round(uploads_bytes / (1024 * 1024), 2)

    # Flask version
    try:
        import flask
        flask_ver = flask.__version__
    except Exception:
        flask_ver = 'Unknown'

    return {
        # DB
        'db_status':    db_status,
        'db_size_kb':   db_size_kb,
        'total_plants': total_plants,
        'total_scans':  total_scans,
        'healthy_scans': healthy_scans,
        'disease_scans': disease_scans,
        'total_activities': total_acts,
        # Storage
        'uploads_mb':   uploads_mb,
        'uploads_files': uploads_files,
        # System
        'python_ver':   sys.version.split()[0],
        'flask_ver':    flask_ver,
        'pillow_ver':   'Not required',
        'gemini_status': 'Configured' if os.environ.get('GEMINI_API_KEY') else 'Not configured',
        'server_port': os.environ.get('PORT', '8080'),
        'platform':     platform.system() + ' ' + platform.release(),
        'arch':         platform.machine(),
        'uptime_since': datetime.datetime.now().strftime('%d %b %Y'),
    }


@settings_bp.route('/settings', methods=['GET'])
def index():
    current_theme = session.get('theme', 'light')
    current_lang  = session.get('language', 'en')
    user_id = current_user_id()
    sysinfo = get_system_info(user_id)
    db = get_db()
    user = db.execute(
        'SELECT * FROM users WHERE id = ?', (user_id,)
    ).fetchone()
    db.close()

    return render_template('settings.html',
        active_page='settings',
        languages=LANGUAGES,
        current_theme=current_theme,
        current_lang=current_lang,
        sysinfo=sysinfo,
        app_version=APP_VERSION,
        app_release=APP_RELEASE_DATE,
        user=user,
    )


@settings_bp.route('/settings/preferences', methods=['POST'])
def update_preferences():
    language = request.form.get('language', 'en')
    theme    = request.form.get('theme', 'light')
    user_mode = request.form.get('user_mode', session.get('user_mode', 'farmer'))
    location = request.form.get('location', '').strip()[:100]
    valid_languages = {language['code'] for language in LANGUAGES}
    if language not in valid_languages:
        language = 'en'
    if theme not in ('light', 'dark'):
        theme = 'light'
    if user_mode not in ('farmer', 'gardener'):
        user_mode = 'farmer'
    session['theme']    = theme
    session['language'] = language
    session['user_mode'] = user_mode
    user_id = current_user_id()
    db = get_db()
    db.execute(
        'UPDATE users SET language = ?, theme = ?, user_mode = ?, location = ? WHERE id = ?',
        (language, theme, user_mode, location or None, user_id)
    )
    db.commit()
    db.close()
    flash('Preferences saved successfully!', 'success')
    return redirect(url_for('settings.index'))


@settings_bp.route('/settings/theme', methods=['POST'])
def toggle_theme():
    data  = request.get_json()
    theme = data.get('theme', 'light') if data else 'light'
    if theme not in ('light', 'dark'):
        return jsonify({'success': False, 'error': 'Invalid theme.'}), 400
    session['theme'] = theme
    db = get_db()
    db.execute(
        'UPDATE users SET theme = ? WHERE id = ?',
        (theme, current_user_id())
    )
    db.commit()
    db.close()
    return jsonify({'success': True, 'theme': theme})


@settings_bp.route('/settings/profile', methods=['POST'])
def update_profile():
    user_id = current_user_id()
    full_name = request.form.get('full_name', '').strip()[:80]
    email = request.form.get('email', '').strip().lower()[:254]
    if (
        not full_name
        or user_id == GUEST_USER_ID
        or not re.fullmatch(r'[^@\s]+@[^@\s]+\.[^@\s]+', email)
    ):
        flash('Enter a valid name and email for a signed-in account.', 'error')
        return redirect(url_for('settings.index'))
    db = get_db()
    try:
        db.execute(
            'UPDATE users SET full_name = ?, email = ? WHERE id = ?',
            (full_name, email, user_id)
        )
        db.commit()
    except sqlite3.IntegrityError:
        db.rollback()
        flash('That email address is already in use.', 'error')
        return redirect(url_for('settings.index'))
    finally:
        db.close()
    session['full_name'] = full_name
    session['email'] = email
    flash('Profile updated.', 'success')
    return redirect(url_for('settings.index'))


@settings_bp.route('/settings/password', methods=['POST'])
def change_password():
    user_id = current_user_id()
    if user_id == GUEST_USER_ID:
        flash('Create or sign in to an account to change a password.', 'warning')
        return redirect(url_for('settings.index'))
    current_password = request.form.get('current_password', '')
    new_password = request.form.get('new_password', '')
    confirm_password = request.form.get('confirm_password', '')
    db = get_db()
    user = db.execute('SELECT password FROM users WHERE id = ?', (user_id,)).fetchone()
    if not user or not check_password_hash(user['password'], current_password):
        db.close()
        flash('Current password was not accepted.', 'error')
        return redirect(url_for('settings.index'))
    if len(new_password) < 8 or new_password != confirm_password:
        db.close()
        flash('Use at least 8 characters and make sure both new passwords match.', 'error')
        return redirect(url_for('settings.index'))
    db.execute(
        'UPDATE users SET password = ? WHERE id = ?',
        (generate_password_hash(new_password, method='pbkdf2:sha256:600000'), user_id)
    )
    db.commit()
    db.close()
    flash('Password changed.', 'success')
    return redirect(url_for('settings.index'))
