from datetime import date

from flask import Blueprint, flash, redirect, render_template, request, url_for

from models.database import get_db
from utils.security import current_user_id

reminders_bp = Blueprint('reminders', __name__)


@reminders_bp.route('/reminders')
def index():
    user_id = current_user_id()
    db = get_db()
    reminders = db.execute(
        """SELECT r.*, p.name AS plant_name
           FROM reminders r
           LEFT JOIN plants p ON p.id = r.plant_id AND p.user_id = r.user_id
           WHERE r.user_id = ?
           ORDER BY r.is_completed ASC, r.reminder_date ASC, r.id DESC
           LIMIT 100""",
        (user_id,)
    ).fetchall()
    plants = db.execute(
        'SELECT id, name FROM plants WHERE user_id = ? ORDER BY name',
        (user_id,)
    ).fetchall()
    db.close()
    return render_template(
        'reminders.html',
        active_page='reminders',
        reminders=reminders,
        plants=plants,
        today=date.today().isoformat()
    )


@reminders_bp.route('/reminders/add', methods=['POST'])
def add():
    user_id = current_user_id()
    title = request.form.get('title', '').strip()[:100]
    reminder_type = request.form.get('reminder_type', 'care')
    reminder_date = request.form.get('reminder_date', '').strip()
    plant_id = request.form.get('plant_id') or None
    if reminder_type not in ('water', 'observe', 'feed', 'care'):
        reminder_type = 'care'
    if not title or not reminder_date:
        flash('Add a reminder name and date.', 'error')
        return redirect(url_for('reminders.index'))
    if plant_id:
        try:
            plant_id = int(plant_id)
        except ValueError:
            flash('Choose a valid plant.', 'error')
            return redirect(url_for('reminders.index'))
    db = get_db()
    if plant_id and not db.execute(
        'SELECT id FROM plants WHERE id = ? AND user_id = ?', (plant_id, user_id)
    ).fetchone():
        db.close()
        flash('That plant is not available in your records.', 'error')
        return redirect(url_for('reminders.index'))
    db.execute(
        """INSERT INTO reminders (user_id, plant_id, title, reminder_type, reminder_date)
           VALUES (?, ?, ?, ?, ?)""",
        (user_id, plant_id, title, reminder_type, reminder_date)
    )
    db.commit()
    db.close()
    flash('Reminder added.', 'success')
    return redirect(url_for('reminders.index'))


@reminders_bp.route('/reminders/<int:reminder_id>/complete', methods=['POST'])
def complete(reminder_id):
    db = get_db()
    db.execute(
        'UPDATE reminders SET is_completed = 1 WHERE id = ? AND user_id = ?',
        (reminder_id, current_user_id())
    )
    db.commit()
    db.close()
    flash('Reminder marked complete.', 'success')
    return redirect(url_for('reminders.index'))


@reminders_bp.route('/reminders/<int:reminder_id>/delete', methods=['POST'])
def delete(reminder_id):
    db = get_db()
    db.execute(
        'DELETE FROM reminders WHERE id = ? AND user_id = ?',
        (reminder_id, current_user_id())
    )
    db.commit()
    db.close()
    flash('Reminder removed.', 'info')
    return redirect(url_for('reminders.index'))
