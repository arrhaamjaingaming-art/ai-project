from flask import Blueprint, render_template, request

from models.database import get_db
from utils.security import current_user_id

recommendations_bp = Blueprint('recommendations', __name__)

COMPANIONS = {
    'tomato': ['Basil', 'Marigold', 'Carrot', 'Onion'],
    'maize': ['Beans', 'Squash', 'Cucumber'],
    'potato': ['Beans', 'Cabbage', 'Marigold'],
    'rice': ['Legumes', 'Marigold', 'Water spinach'],
    'wheat': ['Chickpea', 'Mustard', 'Coriander'],
    'banana': ['Beans', 'Ginger', 'Turmeric'],
    'chilli': ['Basil', 'Onion', 'Marigold'],
    'brinjal': ['Beans', 'Coriander', 'Marigold'],
    'okra': ['Radish', 'Cucumber', 'Sunflower'],
    'cucumber': ['Beans', 'Maize', 'Marigold'],
    'beans': ['Maize', 'Cucumber', 'Carrot'],
    'general': ['Marigold', 'Basil', 'Coriander', 'Beans']
}


@recommendations_bp.route('/recommendations', methods=['GET'])
def index():
    crop = request.args.get('crop', '').strip()[:50]
    season = request.args.get('season', '').strip()[:40]
    space = request.args.get('space', '').strip()[:40]
    growing_method = request.args.get('method', '').strip()[:40]

    db = get_db()
    user = db.execute(
        'SELECT location FROM users WHERE id = ?', (current_user_id(),)
    ).fetchone()
    db.close()
    location = user['location'] if user else ''

    crop_key = crop.lower()
    companions = COMPANIONS.get(crop_key, COMPANIONS['general']) if crop else []
    return render_template(
        'recommendations.html',
        active_page='recommendations',
        crop=crop,
        season=season,
        space=space,
        growing_method=growing_method,
        location=location or '',
        companions=companions
    )
