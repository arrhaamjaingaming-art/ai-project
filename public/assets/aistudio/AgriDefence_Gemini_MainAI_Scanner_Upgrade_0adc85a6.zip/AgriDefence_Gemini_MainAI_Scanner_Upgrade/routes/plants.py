import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, current_app
from models.database import get_db
from utils.helpers import save_image
from utils.security import current_user_id

plants_bp = Blueprint('plants', __name__)

HEALTH_STATUSES = ['healthy', 'diseased', 'recovering', 'unknown']


@plants_bp.route('/plants')
def index():
    user_id = current_user_id()
    search = request.args.get('search', '')
    status_filter = request.args.get('status', '')
    sort_by = request.args.get('sort', 'created_at')

    db = get_db()
    query = 'SELECT * FROM plants WHERE user_id = ?'
    params = [user_id]

    if search:
        query += ' AND (name LIKE ? OR species LIKE ? OR location LIKE ?)'
        like = f'%{search}%'
        params.extend([like, like, like])

    if status_filter:
        query += ' AND health_status = ?'
        params.append(status_filter)

    sort_map = {
        'created_at': 'created_at DESC',
        'name': 'name ASC',
        'health': 'health_status ASC',
    }
    query += f' ORDER BY {sort_map.get(sort_by, "created_at DESC")}'

    plants = db.execute(query, params).fetchall()
    db.close()

    return render_template('plants.html',
        active_page='plants',
        plants=plants,
        search=search,
        status_filter=status_filter,
        sort_by=sort_by,
        health_statuses=HEALTH_STATUSES,
    )


@plants_bp.route('/plants/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        user_id = current_user_id()
        name = request.form.get('name', '').strip()
        species = request.form.get('species', '').strip()
        location = request.form.get('location', '').strip()
        planted_date = request.form.get('planted_date', '')
        notes = request.form.get('notes', '').strip()
        observations = request.form.get('observations', '').strip()

        if not name:
            flash('Plant name is required.', 'error')
            return render_template('plant_form.html', active_page='plants', action='Add', plant=None)

        image_path = None
        if 'image' in request.files and request.files['image'].filename:
            upload_dir = os.path.join(current_app.root_path, 'private_uploads', 'plants')
            filename = save_image(request.files['image'], upload_dir)
            if filename:
                image_path = f'private_uploads/plants/{filename}'

        db = get_db()
        db.execute(
            """INSERT INTO plants
               (user_id, name, species, location, planted_date, notes, observations, image_path)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (user_id, name, species, location, planted_date, notes, observations, image_path)
        )
        db.execute(
            'INSERT INTO activities (user_id, action, description, icon, color) VALUES (?, ?, ?, ?, ?)',
            (user_id, 'Plant Added', f'Added {name} to your garden', 'fa-seedling', 'green')
        )
        db.commit()
        db.close()

        flash(f'{name} added successfully!', 'success')
        return redirect(url_for('plants.index'))

    return render_template('plant_form.html', active_page='plants', action='Add', plant=None)


@plants_bp.route('/plants/edit/<int:plant_id>', methods=['GET', 'POST'])
def edit(plant_id):
    user_id = current_user_id()
    db = get_db()
    plant = db.execute(
        'SELECT * FROM plants WHERE id = ? AND user_id = ?', (plant_id, user_id)
    ).fetchone()

    if not plant:
        db.close()
        flash('Plant not found.', 'error')
        return redirect(url_for('plants.index'))

    if request.method == 'POST':
        name = request.form.get('name', '').strip()
        species = request.form.get('species', '').strip()
        location = request.form.get('location', '').strip()
        planted_date = request.form.get('planted_date', '')
        notes = request.form.get('notes', '').strip()
        observations = request.form.get('observations', '').strip()
        health_status = request.form.get('health_status', 'healthy')

        if not name:
            flash('Plant name is required.', 'error')
            return render_template('plant_form.html', active_page='plants', action='Edit', plant=plant)

        image_path = plant['image_path']
        if 'image' in request.files and request.files['image'].filename:
            upload_dir = os.path.join(current_app.root_path, 'private_uploads', 'plants')
            filename = save_image(request.files['image'], upload_dir)
            if filename:
                image_path = f'private_uploads/plants/{filename}'

        db.execute(
            """UPDATE plants SET name=?, species=?, location=?, planted_date=?,
               notes=?, observations=?, health_status=?, image_path=? WHERE id=? AND user_id=?""",
            (name, species, location, planted_date, notes, observations,
             health_status, image_path, plant_id, user_id)
        )
        db.commit()
        db.close()

        flash(f'{name} updated successfully!', 'success')
        return redirect(url_for('plants.index'))

    db.close()
    return render_template('plant_form.html', active_page='plants', action='Edit', plant=plant, health_statuses=HEALTH_STATUSES)


@plants_bp.route('/plants/delete/<int:plant_id>', methods=['POST'])
def delete(plant_id):
    user_id = current_user_id()
    db = get_db()
    plant = db.execute(
        'SELECT name FROM plants WHERE id = ? AND user_id = ?', (plant_id, user_id)
    ).fetchone()

    if plant:
        db.execute('DELETE FROM reminders WHERE plant_id = ? AND user_id = ?', (plant_id, user_id))
        db.execute('DELETE FROM plants WHERE id = ? AND user_id = ?', (plant_id, user_id))
        db.execute(
            'INSERT INTO activities (user_id, action, description, icon, color) VALUES (?, ?, ?, ?, ?)',
            (user_id, 'Plant Removed', f'Removed {plant["name"]} from your garden', 'fa-trash', 'red')
        )
        db.commit()
        flash(f'{plant["name"]} removed.', 'info')

    db.close()
    return redirect(url_for('plants.index'))
