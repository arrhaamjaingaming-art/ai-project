from flask import Blueprint, render_template, request
from models.database import get_db
from utils.security import current_user_id

history_bp = Blueprint('history', __name__)


@history_bp.route('/history')
def index():
    user_id = current_user_id()
    search = request.args.get('search', '')
    disease_filter = request.args.get('disease', '')
    plant_filter = request.args.get('plant', '')
    try:
        page = max(1, int(request.args.get('page', 1)))
    except (TypeError, ValueError):
        page = 1
    per_page = 10

    db = get_db()

    query = 'SELECT * FROM scans WHERE user_id = ?'
    params = [user_id]

    if search:
        query += ' AND (plant_name LIKE ? OR disease_name LIKE ?)'
        like = f'%{search}%'
        params.extend([like, like])

    if disease_filter:
        query += ' AND disease_key = ?'
        params.append(disease_filter)

    if plant_filter:
        query += ' AND plant_name LIKE ?'
        params.append(f'%{plant_filter}%')

    total = db.execute(
        f'SELECT COUNT(*) as c FROM ({query})', params
    ).fetchone()['c']

    offset = (page - 1) * per_page
    query += ' ORDER BY created_at DESC LIMIT ? OFFSET ?'
    params.extend([per_page, offset])

    scans = db.execute(query, params).fetchall()

    diseases = db.execute(
        'SELECT DISTINCT disease_key, disease_name FROM scans WHERE user_id = ? AND disease_key IS NOT NULL ORDER BY disease_name',
        (user_id,)
    ).fetchall()

    plants_list = db.execute(
        'SELECT DISTINCT plant_name FROM scans WHERE user_id = ? AND plant_name IS NOT NULL ORDER BY plant_name',
        (user_id,)
    ).fetchall()

    db.close()

    total_pages = (total + per_page - 1) // per_page

    return render_template('history.html',
        active_page='history',
        scans=scans,
        diseases=diseases,
        plants_list=plants_list,
        search=search,
        disease_filter=disease_filter,
        plant_filter=plant_filter,
        page=page,
        total_pages=total_pages,
        total=total,
    )
