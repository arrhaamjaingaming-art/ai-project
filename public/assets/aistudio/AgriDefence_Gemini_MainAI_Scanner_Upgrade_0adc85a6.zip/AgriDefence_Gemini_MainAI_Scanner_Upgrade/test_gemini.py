
import os
import requests

api_key = os.environ.get("GEMINI_API_KEY", "").strip()
model = os.environ.get("GEMINI_MODEL", "gemini-3.6-flash").strip()

if not api_key:
    print("GEMINI_API_KEY is missing in this terminal.")
    raise SystemExit(1)

url = (
    "https://generativelanguage.googleapis.com/v1beta/models/"
    + model
    + ":generateContent"
)

try:
    print("Model:", model)
    print("Endpoint:", url)
    response = requests.post(
        url,
        headers={
            "x-goog-api-key": api_key,
            "Content-Type": "application/json",
        },
        json={
            "contents": [
                {
                    "parts": [
                        {"text": "Reply with: Agri Defence test successful"}
                    ]
                }
            ],
            "generationConfig": {
                "maxOutputTokens": 60
            },
        },
        timeout=(10, 90),
    )

    print("HTTP status:", response.status_code)

    try:
        data = response.json()
    except ValueError:
        print("Response was not JSON.")
        print("Content-Type:", response.headers.get("Content-Type"))
        print("Response body:", repr(response.text[:1500]))
        raise SystemExit(1)

    if response.ok:
        for candidate in data.get("candidates", []):
            for part in candidate.get("content", {}).get("parts", []):
                if "text" in part:
                    print("Gemini reply:", part["text"])
    else:
        error = data.get("error", {})
        print("API error:", error.get("message", "No details returned"))

except requests.exceptions.Timeout:
    print("Request timed out.")
except requests.exceptions.ConnectionError:
    print("Connection failed. Check your internet connection.")
