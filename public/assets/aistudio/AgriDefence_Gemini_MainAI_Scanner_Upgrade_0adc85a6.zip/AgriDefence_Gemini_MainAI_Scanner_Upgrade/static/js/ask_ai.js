/* AGRI DEFENCE V3 — ASK AI */

'use strict';

document.addEventListener('DOMContentLoaded', function () {
    const input = document.getElementById('plantImage');
    const choose = document.getElementById('chooseImage');
    const drop = document.getElementById('dropZone');
    const prompt = document.getElementById('uploadPrompt');
    const previewWrap = document.getElementById('imagePreviewWrap');
    const preview = document.getElementById('imagePreview');
    const remove = document.getElementById('removeImage');
    const question = document.getElementById('plantQuestion');
    const analyze = document.getElementById('analyzeBtn');
    const empty = document.getElementById('analysisEmpty');
    const loading = document.getElementById('analysisLoading');
    const result = document.getElementById('analysisResult');
    const resultImage = document.getElementById('resultImage');
    const resultAnswer = document.getElementById('resultAnswer');

    if (!input || !drop || !analyze) return;

    function showPreview(file) {
        if (!file) return;

        const allowed = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowed.includes(file.type)) {
            alert('Please choose JPG, PNG or WEBP.');
            return;
        }

        const url = URL.createObjectURL(file);
        preview.src = url;
        prompt.classList.add('hidden');
        previewWrap.classList.remove('hidden');
    }

    choose.addEventListener('click', function (e) {
        e.stopPropagation();
        input.click();
    });

    drop.addEventListener('click', function () {
        if (previewWrap.classList.contains('hidden')) input.click();
    });

    input.addEventListener('change', function () {
        showPreview(this.files[0]);
    });

    ['dragenter', 'dragover'].forEach(function (eventName) {
        drop.addEventListener(eventName, function (e) {
            e.preventDefault();
            drop.classList.add('dragging');
        });
    });

    ['dragleave', 'drop'].forEach(function (eventName) {
        drop.addEventListener(eventName, function (e) {
            e.preventDefault();
            drop.classList.remove('dragging');
        });
    });

    drop.addEventListener('drop', function (e) {
        const file = e.dataTransfer.files[0];
        if (!file) return;

        try {
            const dt = new DataTransfer();
            dt.items.add(file);
            input.files = dt.files;
        } catch (err) {
            // Preview still works even if browser blocks assignment.
        }

        showPreview(file);
    });

    remove.addEventListener('click', function (e) {
        e.stopPropagation();
        input.value = '';
        preview.src = '';
        previewWrap.classList.add('hidden');
        prompt.classList.remove('hidden');
    });

    analyze.addEventListener('click', async function () {
        if (!input.files.length) {
            alert('Please upload a plant image first.');
            return;
        }

        const form = new FormData();
        form.append('image', input.files[0]);
        form.append('question', question.value.trim());

        analyze.disabled = true;
        empty.classList.add('hidden');
        result.classList.add('hidden');
        loading.classList.remove('hidden');

        try {
            const response = await fetch('/ai/api/analyze', {
                method: 'POST',
                body: form
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'Plant analysis failed.');
            }

            loading.classList.add('hidden');
            result.classList.remove('hidden');

            resultImage.src = data.image;
            resultAnswer.textContent = data.answer;

        } catch (error) {
            loading.classList.add('hidden');
            empty.classList.remove('hidden');

            if (typeof showToast === 'function') {
                showToast(error.message, 'error');
            } else {
                alert(error.message);
            }

        } finally {
            analyze.disabled = false;
        }
    });
});
