/* ============================================
   AGRI DEFENCE V3 — Main JavaScript
   ============================================ */

'use strict';

// ---- App Init ----
document.addEventListener('DOMContentLoaded', function () {
    initLoading();
    initSidebar();
    initNavbar();
    initTheme();
    initRipple();
    initFAB();
    initDropdowns();
    initFlashMessages();
    updateGreeting();
    setInterval(updateGreeting, 60000);
});

// ---- Loading Overlay ----
function initLoading() {
    const overlay = document.getElementById('loading-overlay');
    if (!overlay) return;
    setTimeout(() => overlay.classList.add('hidden'), 800);
    setTimeout(() => overlay.remove(), 1400);
}

// ---- Sidebar ----
function initSidebar() {
    const sidebar = document.getElementById('sidebar');
    const toggle = document.getElementById('sidebarToggle');
    const mobileBtn = document.getElementById('mobileMenuBtn');
    const overlay = document.getElementById('sidebarOverlay');
    const mainArea = document.getElementById('mainArea');

    if (!sidebar) return;

    // Restore collapsed state
    const isCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
    if (isCollapsed && window.innerWidth > 768) sidebar.classList.add('collapsed');

    // Desktop toggle
    if (toggle) {
        toggle.addEventListener('click', function () {
            if (window.innerWidth <= 768) {
                closeMobileMenu();
            } else {
                sidebar.classList.toggle('collapsed');
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            }
        });
    }

    // Mobile toggle
    if (mobileBtn) {
        mobileBtn.addEventListener('click', function () {
            sidebar.classList.toggle('mobile-open');
            overlay.classList.toggle('active');
            document.body.style.overflow = sidebar.classList.contains('mobile-open') ? 'hidden' : '';
        });
    }

    // Close on overlay click
    if (overlay) {
        overlay.addEventListener('click', closeMobileMenu);
    }

    function closeMobileMenu() {
        sidebar.classList.remove('mobile-open');
        overlay.classList.remove('active');
        document.body.style.overflow = '';
    }

    // Close on ESC
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') {
            closeMobileMenu();
            closeAllDropdowns();
        }
    });

    // Nav tooltips for collapsed state
    document.querySelectorAll('.nav-item').forEach(item => {
        const text = item.querySelector('.nav-text');
        if (text) item.setAttribute('data-label', text.textContent.trim());
    });
}

// ---- Navbar / Dropdowns ----
function initNavbar() {
    const notifWrapper = document.getElementById('notifWrapper');
    const notifBtn = document.getElementById('notifBtn');
    const userProfileWrapper = document.getElementById('userProfileWrapper');
    const userProfileBtn = document.getElementById('userProfileBtn');

    if (notifBtn && notifWrapper) {
        notifBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            const isOpen = notifWrapper.classList.contains('open');
            closeAllDropdowns();
            if (!isOpen) {
                notifWrapper.classList.add('open');
                document.getElementById('notifBtn').querySelector('.notif-dot')?.remove();
            }
        });
    }

    if (userProfileBtn && userProfileWrapper) {
        userProfileBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            const isOpen = userProfileWrapper.classList.contains('open');
            closeAllDropdowns();
            if (!isOpen) userProfileWrapper.classList.add('open');
        });
    }

    document.addEventListener('click', closeAllDropdowns);
}

function closeAllDropdowns() {
    document.querySelectorAll('.notif-wrapper.open, .user-profile-wrapper.open').forEach(el => el.classList.remove('open'));
}

function initDropdowns() {
    // Mark all read
    document.querySelector('.mark-read-btn')?.addEventListener('click', function () {
        document.querySelectorAll('.notif-item.unread').forEach(n => n.classList.remove('unread'));
        showToast('All notifications marked as read', 'success');
    });
}

// ---- Theme Toggle ----
function initTheme() {
    const html = document.documentElement;
    const btn = document.getElementById('themeToggleBtn');
    const icon = document.getElementById('themeIcon');
    const savedTheme = localStorage.getItem('theme') || html.getAttribute('data-theme') || 'light';

    applyTheme(savedTheme);

    if (btn) {
        btn.addEventListener('click', function () {
            const current = html.getAttribute('data-theme');
            const next = current === 'dark' ? 'light' : 'dark';
            applyTheme(next);
            localStorage.setItem('theme', next);
            // Persist to server silently
            fetch('/settings/theme', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ theme: next })
            }).catch(() => {});
        });
    }

    function applyTheme(theme) {
        html.setAttribute('data-theme', theme);
        if (icon) {
            icon.className = theme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        }
    }
}

// ---- Ripple Effect ----
function initRipple() {
    document.addEventListener('click', function (e) {
        const target = e.target.closest('.ripple');
        if (!target) return;
        const rect = target.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const size = Math.max(rect.width, rect.height) * 2;
        const wave = document.createElement('span');
        wave.className = 'ripple-wave';
        wave.style.cssText = `width:${size}px;height:${size}px;left:${x - size/2}px;top:${y - size/2}px`;
        target.appendChild(wave);
        wave.addEventListener('animationend', () => wave.remove());
    });
}

// ---- FAB ----
function initFAB() {
    const fab = document.getElementById('fabContainer');
    const fabBtn = document.getElementById('fabMainBtn');
    if (!fab || !fabBtn) return;

    fabBtn.addEventListener('click', function (e) {
        e.stopPropagation();
        fab.classList.toggle('open');
    });

    document.addEventListener('click', function (e) {
        if (!fab.contains(e.target)) fab.classList.remove('open');
    });
}

// ---- Flash Messages Auto-dismiss ----
function initFlashMessages() {
    document.querySelectorAll('.flash-msg').forEach(msg => {
        setTimeout(() => {
            msg.style.transition = 'opacity .4s ease, transform .4s ease';
            msg.style.opacity = '0';
            msg.style.transform = 'translateX(20px)';
            setTimeout(() => msg.remove(), 400);
        }, 5000);
    });
}

// ---- Greeting ----
function updateGreeting() {
    const el = document.getElementById('timeGreeting');
    if (!el) return;
    const h = new Date().getHours();
    el.textContent = h < 12 ? 'Good Morning' : h < 17 ? 'Good Afternoon' : h < 21 ? 'Good Evening' : 'Good Night';
}

// ---- Toast Notifications ----
window.showToast = function (message, type = 'info', duration = 4000) {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const icons = { success: 'fa-check-circle', error: 'fa-exclamation-circle', warning: 'fa-exclamation-triangle', info: 'fa-info-circle' };
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas ${icons[type] || icons.info}"></i>
        <span>${escapeHtml(message)}</span>
        <button class="toast-close" onclick="this.closest('.toast').remove()">
            <i class="fas fa-times"></i>
        </button>`;
    container.appendChild(toast);

    setTimeout(() => {
        toast.classList.add('removing');
        setTimeout(() => toast.remove(), 300);
    }, duration);
};

function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// ---- Global Search ----
document.getElementById('globalSearch')?.addEventListener('keydown', function (e) {
    if (e.key === 'Enter' && this.value.trim()) {
        window.location.href = `/plants?search=${encodeURIComponent(this.value.trim())}`;
    }
});

// Cmd/Ctrl+K shortcut
document.addEventListener('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        document.getElementById('globalSearch')?.focus();
    }
});

// ---- Sidebar search filter ----
document.getElementById('sidebarSearch')?.addEventListener('input', function () {
    const q = this.value.toLowerCase();
    document.querySelectorAll('.nav-item').forEach(item => {
        const text = item.querySelector('.nav-text')?.textContent.toLowerCase() || '';
        item.style.display = (!q || text.includes(q)) ? '' : 'none';
    });
});

// ---- Animated counter helper ----
function animateCounter(el, target, duration = 1200) {
    const start = performance.now();
    const step = (timestamp) => {
        const progress = Math.min((timestamp - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.floor(eased * target);
        if (progress < 1) requestAnimationFrame(step);
        else el.textContent = target;
    };
    requestAnimationFrame(step);
}

// Initialize page counters via Intersection Observer
const counters = document.querySelectorAll('.counter[data-target]');
if (counters.length && 'IntersectionObserver' in window) {
    const obs = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const el = entry.target;
                const target = parseInt(el.dataset.target) || 0;
                animateCounter(el, target);
                obs.unobserve(el);
            }
        });
    }, { threshold: 0.3 });
    counters.forEach(c => obs.observe(c));
} else {
    counters.forEach(c => { c.textContent = c.dataset.target || '0'; });
}
