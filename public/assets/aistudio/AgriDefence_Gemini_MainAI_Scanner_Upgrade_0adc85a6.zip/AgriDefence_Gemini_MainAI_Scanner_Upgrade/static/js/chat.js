/* AGRI DEFENCE V3 — AI CHAT */

'use strict';

document.addEventListener('DOMContentLoaded', function () {
    const input = document.getElementById('aiMessageInput');
    const sendBtn = document.getElementById('aiSendBtn');
    const messages = document.getElementById('aiMessages');
    const typing = document.getElementById('aiTyping');
    const clearBtn = document.getElementById('clearChatBtn');

    if (!input || !sendBtn || !messages) return;

    function scrollToBottom() {
        messages.scrollTop = messages.scrollHeight;
    }

    function resizeInput() {
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 130) + 'px';
    }

    function addMessage(text, type) {
        const wrapper = document.createElement('div');
        wrapper.className = 'ai-message ' + type;

        const avatar = document.createElement('div');
        avatar.className = 'ai-message-avatar';
        avatar.textContent = type === 'assistant' ? '🌱' : '👤';

        const content = document.createElement('div');
        content.className = 'ai-message-content';

        const bubble = document.createElement('div');
        bubble.className = 'ai-message-bubble';
        bubble.textContent = text;

        const time = document.createElement('div');
        time.className = 'ai-message-time';
        time.textContent = new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });

        content.appendChild(bubble);
        content.appendChild(time);
        wrapper.appendChild(avatar);
        wrapper.appendChild(content);
        messages.appendChild(wrapper);
        scrollToBottom();
    }

    async function sendMessage(message) {
        message = String(message).trim();
        if (!message) return;

        const welcome = messages.querySelector('.ai-welcome');
        if (welcome) welcome.remove();

        addMessage(message, 'user');
        input.value = '';
        resizeInput();
        sendBtn.disabled = true;
        typing.classList.add('active');
        scrollToBottom();

        try {
            const response = await fetch('/ai/api/chat', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({message: message})
            });

            const data = await response.json();

            if (!response.ok || !data.success) {
                throw new Error(data.error || 'AI request failed.');
            }

            addMessage(data.answer, 'assistant');

        } catch (error) {
            console.error('AI CHAT ERROR:', error);
            addMessage('⚠️ Sorry, I could not get a response.\n\n' + error.message, 'assistant');

            if (typeof showToast === 'function') {
                showToast(error.message, 'error');
            }
        } finally {
            typing.classList.remove('active');
            sendBtn.disabled = false;
            input.focus();
            scrollToBottom();
        }
    }

    sendBtn.addEventListener('click', function () {
        sendMessage(input.value);
    });

    input.addEventListener('input', resizeInput);

    input.addEventListener('keydown', function (event) {
        if (event.key === 'Enter' && !event.shiftKey) {
            event.preventDefault();
            sendMessage(input.value);
        }
    });

    function bindSuggestions() {
        document.querySelectorAll('.ai-suggestion').forEach(function (button) {
            button.addEventListener('click', function () {
                input.value = this.dataset.question || '';
                resizeInput();
                input.focus();
            });
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            if (!confirm('Clear this conversation?')) return;

            location.reload();

            if (typeof showToast === 'function') {
                showToast('Chat cleared', 'success');
            }
        });
    }

    bindSuggestions();
    resizeInput();
});
