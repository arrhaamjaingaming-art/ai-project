AGRI DEFENCE V3 — AI UPGRADE
===============================

This package adds:
1. AI Assistant chat page
2. Ask AI image-analysis page
3. Flask AI blueprint/API routes
4. Updated app.py blueprint registration
5. Page-specific CSS/JS matching the existing Agri Defence V3 theme

IMPORTANT:
- Your existing ai/chatbot.py is NOT overwritten.
- Your Gemini API key is NOT included.
- Your existing main.css and main.js are NOT overwritten.
- Your existing base.html is NOT overwritten because it contains your full application shell.
  Add the sidebar snippet from base_sidebar_patch.html to the existing MAIN MENU.

FILES:
routes/ai.py
templates/chat.html
templates/ask_ai.html
static/css/chat.css
static/css/ask_ai.css
static/js/chat.js
static/js/ask_ai.js
app.py
base_sidebar_patch.html

INSTALL:
1. Copy routes/ai.py into your routes folder.
2. Copy templates/chat.html and ask_ai.html into templates.
3. Copy chat.css and ask_ai.css into static/css.
4. Copy chat.js and ask_ai.js into static/js.
5. Replace your app.py with the included app.py OR add:
       from routes.ai import ai_bp
   and:
       app.register_blueprint(ai_bp)
6. Add base_sidebar_patch.html contents into the MAIN MENU of base.html.
7. Keep your working ai/chatbot.py exactly as it is.
8. Set GEMINI_API_KEY in your CMD before starting Flask.
9. Start:
       python app.py

PAGES:
http://127.0.0.1:8080/ai/chat
http://127.0.0.1:8080/ai/ask

The image page currently sends the image to your working Gemini image-analysis
method. MobileNetV2 can be connected later so the final pipeline becomes:

Image -> MobileNetV2 disease classification -> Gemini explanation/treatment/prevention
