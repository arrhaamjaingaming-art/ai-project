TRANSLATIONS = {
    'en': {},
    'hi': {
        'Dashboard': 'डैशबोर्ड', 'AI Scan': 'पौधा स्कैन', 'My Plants': 'मेरे पौधे',
        'Crop Advice': 'फसल सलाह', 'AI Assistant': 'AI सहायक', 'Weather': 'मौसम',
        'History': 'स्कैन इतिहास', 'Reports': 'रिपोर्ट', 'Reminders': 'देखभाल याद दिलाएँ',
        'Settings': 'सेटिंग्स', 'About Agri Defence': 'Agri Defence के बारे में',
    },
    'ta': {
        'Dashboard': 'முகப்பு', 'AI Scan': 'தாவர ஸ்கேன்', 'My Plants': 'என் தாவரங்கள்',
        'Crop Advice': 'பயிர் ஆலோசனை', 'AI Assistant': 'AI உதவியாளர்', 'Weather': 'வானிலை',
        'History': 'ஸ்கேன் வரலாறு', 'Reports': 'அறிக்கைகள்', 'Reminders': 'பராமரிப்பு நினைவூட்டல்கள்',
        'Settings': 'அமைப்புகள்', 'About Agri Defence': 'Agri Defence பற்றி',
    },
    'te': {
        'Dashboard': 'డ్యాష్‌బోర్డ్', 'AI Scan': 'మొక్క స్కాన్', 'My Plants': 'నా మొక్కలు',
        'Crop Advice': 'పంట సలహా', 'AI Assistant': 'AI సహాయకుడు', 'Weather': 'వాతావరణం',
        'History': 'స్కాన్ చరిత్ర', 'Reports': 'నివేదికలు', 'Reminders': 'సంరక్షణ రిమైండర్లు',
        'Settings': 'సెట్టింగ్‌లు', 'About Agri Defence': 'Agri Defence గురించి',
    },
    'bn': {
        'Dashboard': 'ড্যাশবোর্ড', 'AI Scan': 'গাছ স্ক্যান', 'My Plants': 'আমার গাছ',
        'Crop Advice': 'ফসলের পরামর্শ', 'AI Assistant': 'AI সহায়ক', 'Weather': 'আবহাওয়া',
        'History': 'স্ক্যানের ইতিহাস', 'Reports': 'প্রতিবেদন', 'Reminders': 'যত্নের অনুস্মারক',
        'Settings': 'সেটিংস', 'About Agri Defence': 'Agri Defence সম্পর্কে',
    },
    'mr': {
        'Dashboard': 'डॅशबोर्ड', 'AI Scan': 'वनस्पती स्कॅन', 'My Plants': 'माझी झाडे',
        'Crop Advice': 'पीक सल्ला', 'AI Assistant': 'AI सहाय्यक', 'Weather': 'हवामान',
        'History': 'स्कॅन इतिहास', 'Reports': 'अहवाल', 'Reminders': 'देखभाल स्मरणपत्रे',
        'Settings': 'सेटिंग्ज', 'About Agri Defence': 'Agri Defence विषयी',
    },
    'kn': {
        'Dashboard': 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್', 'AI Scan': 'ಸಸ್ಯ ಸ್ಕ್ಯಾನ್', 'My Plants': 'ನನ್ನ ಸಸ್ಯಗಳು',
        'Crop Advice': 'ಬೆಳೆ ಸಲಹೆ', 'AI Assistant': 'AI ಸಹಾಯಕ', 'Weather': 'ಹವಾಮಾನ',
        'History': 'ಸ್ಕ್ಯಾನ್ ಇತಿಹಾಸ', 'Reports': 'ವರದಿಗಳು', 'Reminders': 'ಆರೈಕೆ ನೆನಪುಗಳು',
        'Settings': 'ಸೆಟ್ಟಿಂಗ್‌ಗಳು', 'About Agri Defence': 'Agri Defence ಬಗ್ಗೆ',
    },
    'ml': {
        'Dashboard': 'ഡാഷ്ബോർഡ്', 'AI Scan': 'ചെടി സ്കാൻ', 'My Plants': 'എന്റെ ചെടികൾ',
        'Crop Advice': 'വിള ഉപദേശം', 'AI Assistant': 'AI സഹായി', 'Weather': 'കാലാവസ്ഥ',
        'History': 'സ്കാൻ ചരിത്രം', 'Reports': 'റിപ്പോർട്ടുകൾ', 'Reminders': 'പരിചരണ ഓർമ്മപ്പെടുത്തലുകൾ',
        'Settings': 'ക്രമീകരണങ്ങൾ', 'About Agri Defence': 'Agri Defence കുറിച്ച്',
    },
    'gu': {
        'Dashboard': 'ડેશબોર્ડ', 'AI Scan': 'છોડ સ્કેન', 'My Plants': 'મારા છોડ',
        'Crop Advice': 'પાક સલાહ', 'AI Assistant': 'AI સહાયક', 'Weather': 'હવામાન',
        'History': 'સ્કેન ઇતિહાસ', 'Reports': 'અહેવાલો', 'Reminders': 'સંભાળ યાદ અપાવણીઓ',
        'Settings': 'સેટિંગ્સ', 'About Agri Defence': 'Agri Defence વિશે',
    },
    'pa': {
        'Dashboard': 'ਡੈਸ਼ਬੋਰਡ', 'AI Scan': 'ਪੌਦੇ ਦੀ ਜਾਂਚ', 'My Plants': 'ਮੇਰੇ ਪੌਦੇ',
        'Crop Advice': 'ਫਸਲ ਸਲਾਹ', 'AI Assistant': 'AI ਸਹਾਇਕ', 'Weather': 'ਮੌਸਮ',
        'History': 'ਸਕੈਨ ਇਤਿਹਾਸ', 'Reports': 'ਰਿਪੋਰਟਾਂ', 'Reminders': 'ਦੇਖਭਾਲ ਯਾਦ-ਦਿਹਾਨੀਆਂ',
        'Settings': 'ਸੈਟਿੰਗਾਂ', 'About Agri Defence': 'Agri Defence ਬਾਰੇ',
    },
    'or': {
        'Dashboard': 'ଡ୍ୟାସବୋର୍ଡ', 'AI Scan': 'ଗଛ ସ୍କାନ୍', 'My Plants': 'ମୋ ଗଛ',
        'Crop Advice': 'ଫସଲ ପରାମର୍ଶ', 'AI Assistant': 'AI ସହାୟକ', 'Weather': 'ପାଣିପାଗ',
        'History': 'ସ୍କାନ୍ ଇତିହାସ', 'Reports': 'ରିପୋର୍ଟ', 'Reminders': 'ଯତ୍ନ ସ୍ମାରକ',
        'Settings': 'ସେଟିଂସ୍', 'About Agri Defence': 'Agri Defence ବିଷୟରେ',
    },
    'ur': {
        'Dashboard': 'ڈیش بورڈ', 'AI Scan': 'پودے کا اسکین', 'My Plants': 'میرے پودے',
        'Crop Advice': 'فصل کا مشورہ', 'AI Assistant': 'AI معاون', 'Weather': 'موسم',
        'History': 'اسکین کی تاریخ', 'Reports': 'رپورٹس', 'Reminders': 'دیکھ بھال کی یاددہانیاں',
        'Settings': 'ترتیبات', 'About Agri Defence': 'Agri Defence کے بارے میں',
    },
}

LANGUAGE_NAMES = {
    'en': 'English', 'hi': 'Hindi', 'ta': 'Tamil', 'te': 'Telugu',
    'bn': 'Bengali', 'mr': 'Marathi', 'kn': 'Kannada', 'ml': 'Malayalam',
    'gu': 'Gujarati', 'pa': 'Punjabi', 'or': 'Odia', 'ur': 'Urdu'
}


def translate(language, message):
    return TRANSLATIONS.get(language, {}).get(message, message)
