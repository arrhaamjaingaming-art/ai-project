import secrets
from flask import session

from models.database import GUEST_USER_ID


def current_user_id():
    """Return the signed-in user's id, or the legacy guest account id."""
    value = session.get('user_id', GUEST_USER_ID)
    try:
        return int(value)
    except (TypeError, ValueError):
        session.pop('user_id', None)
        return GUEST_USER_ID


def csrf_token():
    """Create or return the per-session CSRF token used by forms and fetch."""
    token = session.get('_csrf_token')
    if not token:
        token = secrets.token_urlsafe(32)
        session['_csrf_token'] = token
    return token
