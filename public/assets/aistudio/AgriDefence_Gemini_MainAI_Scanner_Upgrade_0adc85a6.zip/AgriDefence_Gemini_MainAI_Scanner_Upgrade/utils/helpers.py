import os
import uuid

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp'}

GUEST_USER_ID = 1


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_image(file, folder):
    if file and allowed_file(file.filename):
        ext = file.filename.rsplit('.', 1)[1].lower()
        filename = f"{uuid.uuid4().hex}.{ext}"
        os.makedirs(folder, exist_ok=True)
        filepath = os.path.join(folder, filename)
        file.save(filepath)
        return filename
    return None


DISEASES = {
    'healthy': {
        'name': 'Healthy Plant',
        'severity': 'none',
        'description': 'The plant appears to be in excellent health with no visible signs of disease, pest infestation, or nutritional deficiency. Leaf color, texture, and overall structure look optimal. Chlorophyll distribution is uniform and the leaf surface shows no anomalous lesions.',
        'treatment': 'No treatment required. Continue your current care routine: water consistently, ensure adequate sunlight, and maintain your fertilization schedule.',
        'prevention': 'Continue regular monitoring, maintain proper plant spacing, apply preventive foliar sprays during high-humidity periods, and inspect undersides of leaves weekly.',
        'affected_parts': 'None',
        'symptoms': 'No symptoms detected',
    },
    'early_blight': {
        'name': 'Early Blight (Alternaria solani)',
        'severity': 'moderate',
        'description': 'Early blight is a fungal disease characterized by dark brown to black necrotic spots with concentric rings forming a target-board pattern on older/lower leaves. Surrounded by a yellow chlorotic halo. Causes premature defoliation and yield loss of 20–30%.',
        'treatment': 'Apply copper-based fungicide or mancozeb (2 g/L water) every 7–10 days. Remove and destroy all infected leaves immediately. Improve air circulation. Avoid wetting foliage during irrigation.',
        'prevention': 'Use certified disease-free seeds, practice 2–3 year crop rotation, avoid overhead irrigation, maintain proper plant spacing, remove plant debris after harvest, and apply preventive fungicide before monsoon season.',
        'affected_parts': 'Older leaves, stems, fruit',
        'symptoms': 'Dark concentric lesions, yellowing margins, brown necrosis',
    },
    'late_blight': {
        'name': 'Late Blight (Phytophthora infestans)',
        'severity': 'severe',
        'description': 'Late blight is a highly destructive oomycete pathogen causing water-soaked, irregular dark olive-to-brown lesions on leaves. White sporulating mycelium appears on leaf undersides during humid conditions. Can devastate entire fields within 7–10 days under favorable weather.',
        'treatment': 'Apply metalaxyl + mancozeb fungicide immediately upon detection. Remove and bag severely infected plants — do not compost. Avoid overhead irrigation at night. Spray every 5–7 days during cool, humid periods.',
        'prevention': 'Plant resistant varieties (e.g. Sarpo Mira, Defender), use certified disease-free seed tubers, practice crop rotation, apply preventive fungicides before disease onset, and ensure good drainage.',
        'affected_parts': 'Leaves, stems, tubers, fruit',
        'symptoms': 'Water-soaked lesions, white mold on underside, rapid browning',
    },
    'powdery_mildew': {
        'name': 'Powdery Mildew (Erysiphe cichoracearum)',
        'severity': 'mild',
        'description': 'Powdery mildew appears as white to gray talcum-like powder on leaf surfaces, stems, and young buds. Unlike most fungal diseases, it thrives in warm, dry climates with high relative humidity at night. Reduces photosynthesis, causes premature leaf drop, and lowers fruit quality.',
        'treatment': 'Apply sulfur-based fungicide or potassium bicarbonate spray (10 g/L). Neem oil solution (5 mL/L) is an effective organic alternative. Remove and destroy heavily infected leaves. Avoid nitrogen overfertilization.',
        'prevention': 'Plant resistant varieties, ensure 60 cm+ spacing for air circulation, avoid excessive nitrogen, apply preventive sulfur sprays in dry weather, and water at the base rather than overhead.',
        'affected_parts': 'Upper leaf surface, stems, buds',
        'symptoms': 'White powdery coating, stunted growth, leaf distortion',
    },
    'leaf_rust': {
        'name': 'Leaf Rust (Puccinia spp.)',
        'severity': 'moderate',
        'description': 'Leaf rust presents as orange-brown to reddish-brown pustules (uredinia) on the upper and lower leaf surfaces. Each pustule releases thousands of wind-borne spores. Under cool, moist conditions it spreads explosively across fields, causing significant yield losses of 10–40%.',
        'treatment': 'Apply triazole fungicides (tebuconazole 250 mL/ha or propiconazole) at the first sign of disease. Repeat every 14 days. Ensure thorough coverage including leaf undersides.',
        'prevention': 'Grow rust-resistant varieties, apply preventive fungicides, monitor fields closely during cool moist weather, practice crop rotation, and destroy crop debris post-harvest.',
        'affected_parts': 'Both leaf surfaces, occasionally stems',
        'symptoms': 'Orange-brown pustules, yellow streaks, premature drying',
    },
    'bacterial_blight': {
        'name': 'Bacterial Blight (Xanthomonas oryzae)',
        'severity': 'severe',
        'description': 'Bacterial blight causes water-soaked to yellowish leaf margins that turn straw-brown and necrotic, giving a "fire-scorched" appearance. A diagnostic feature is bacterial ooze visible in early morning under humid conditions. Causes 20–50% yield loss in susceptible varieties.',
        'treatment': 'Apply copper hydroxide (3 g/L) or streptomycin sulfate (0.5 g/L) spray. Remove infected plant material and avoid working in wet fields to prevent mechanical spread. Ensure proper field drainage.',
        'prevention': 'Use certified disease-free seeds, plant resistant varieties, avoid high nitrogen fertilization, practice balanced nutrition with potassium, and maintain proper field drainage.',
        'affected_parts': 'Leaf margins, young leaves, seedlings',
        'symptoms': 'Water-soaked margins, yellow to brown necrosis, bacterial ooze',
    },
    'root_rot': {
        'name': 'Root Rot (Fusarium / Phytophthora spp.)',
        'severity': 'severe',
        'description': 'Root rot causes roots to turn dark brown and mushy with a foul odor, leading to wilting, yellowing, and eventual plant collapse. The vascular system becomes discolored (often red-brown in Fusarium). Overwatering and poor drainage are primary contributing factors.',
        'treatment': 'Improve soil drainage immediately. Apply Trichoderma-based biocontrol drench (10 g/L). Apply metalaxyl fungicide root drench. Remove severely affected plants. Allow soil to dry before next irrigation.',
        'prevention': 'Ensure excellent soil drainage, use raised beds, avoid waterlogging, treat seeds with fungicide before planting, practice 3-year crop rotation with cereals, use resistant rootstocks where available.',
        'affected_parts': 'Roots, crown, lower stem',
        'symptoms': 'Wilting, yellowing, brown roots, vascular discoloration',
    },
    'anthracnose': {
        'name': 'Anthracnose (Colletotrichum spp.)',
        'severity': 'moderate',
        'description': 'Anthracnose causes sunken, dark-bordered lesions with salmon-pink spore masses on fruits, leaves, and stems. The pathogen can persist on plant debris for years. High humidity and warm temperatures (25–30°C) favor rapid disease development and spread.',
        'treatment': 'Apply mancozeb (2 g/L) or copper-based fungicide at 10-day intervals. Remove infected plant debris. Ensure good air circulation. Avoid overhead irrigation and harvest during dry conditions.',
        'prevention': 'Use disease-free seed/planting material, practice crop rotation, avoid overhead irrigation, apply preventive fungicide sprays during humid weather, and maintain field hygiene by removing crop residues.',
        'affected_parts': 'Leaves, stems, fruits, pods',
        'symptoms': 'Sunken dark lesions, salmon-pink spore masses, dieback',
    },
    'mosaic_virus': {
        'name': 'Mosaic Virus (TMV / CMV)',
        'severity': 'moderate',
        'description': 'Mosaic virus causes characteristic mottled yellow-green discoloration of leaves in an irregular mosaic pattern, leaf distortion, blistering, and stunted growth. Spread by aphid vectors and through infected plant sap on tools. No chemical cure exists; prevention is critical.',
        'treatment': 'No cure for viral infections. Remove and destroy infected plants immediately to prevent further spread. Control aphid vectors with imidacloprid or reflective silver mulches. Disinfect all tools with 10% bleach solution between plants.',
        'prevention': 'Use virus-indexed certified seeds, plant resistant/tolerant varieties, control insect vectors especially aphids, avoid tobacco products near susceptible plants, and practice strict field hygiene.',
        'affected_parts': 'Young leaves, shoot tips, fruits',
        'symptoms': 'Yellow-green mosaic pattern, leaf distortion, stunting',
    },
    'nutrient_deficiency': {
        'name': 'Nutrient Deficiency (N/P/K)',
        'severity': 'mild',
        'description': 'Nutrient deficiencies cause distinct visual symptoms: nitrogen deficiency shows as uniform yellowing starting from older leaves; phosphorus deficiency causes purple-red discoloration of leaf undersides; potassium deficiency results in brown scorched leaf margins and weak stems. Can reduce yield by 15–30%.',
        'treatment': 'Conduct soil test to identify the specific deficiency. Apply urea (46% N) for nitrogen, DAP (18% N, 46% P2O5) for phosphorus, or MOP (60% K2O) for potassium. Foliar spray of micronutrient mix for quick correction.',
        'prevention': 'Conduct regular soil testing every season, maintain a balanced NPK fertilization program, incorporate organic matter to improve nutrient retention, and maintain soil pH between 6.0–7.0 for optimal nutrient availability.',
        'affected_parts': 'Leaves (pattern depends on nutrient)',
        'symptoms': 'Yellowing, purple discoloration, marginal burn',
    },
}


def analyze_image_colors(image_path):
    """
    Analyze image pixel data to extract color-based features.
    Returns a dict of feature scores that guide disease prediction.
    """
    try:
        from PIL import Image
        import numpy as np

        img = Image.open(image_path).convert('RGB')
        # Resize for fast analysis
        img = img.resize((150, 150), Image.LANCZOS)
        pixels = list(img.getdata())

        total = len(pixels)
        if total == 0:
            return None

        # Counters
        green_count = yellow_count = brown_count = white_count = 0
        dark_count = orange_count = gray_count = 0
        r_sum = g_sum = b_sum = 0

        for r, g, b in pixels:
            r_sum += r
            g_sum += g
            b_sum += b

            mx = max(r, g, b)
            mn = min(r, g, b)
            brightness = (mx + mn) / 2

            # Dark pixels (necrosis, rot, blight lesions)
            if brightness < 55:
                dark_count += 1
                continue

            # White/gray pixels (powdery mildew)
            if mx - mn < 25:
                if brightness > 180:
                    white_count += 1
                elif brightness > 100:
                    gray_count += 1
                continue

            # Green (healthy tissue)
            if g > r and g > b and (g - max(r, b)) > 20:
                green_count += 1

            # Yellow (chlorosis, nutrient deficiency, mosaic)
            elif r > 140 and g > 120 and b < 90 and r > b and g > b:
                yellow_count += 1

            # Orange-brown (rust, early blight, anthracnose)
            elif r > 140 and g > 60 and b < 80 and r > g:
                if g > 90:
                    orange_count += 1  # rust
                else:
                    brown_count += 1   # blight / anthracnose

        avg_r = r_sum / total
        avg_g = g_sum / total
        avg_b = b_sum / total

        return {
            'green_ratio':  green_count / total,
            'yellow_ratio': yellow_count / total,
            'brown_ratio':  brown_count / total,
            'orange_ratio': orange_count / total,
            'white_ratio':  white_count / total,
            'gray_ratio':   gray_count / total,
            'dark_ratio':   dark_count / total,
            'avg_r': avg_r,
            'avg_g': avg_g,
            'avg_b': avg_b,
            'avg_brightness': (avg_r + avg_g + avg_b) / 3,
        }
    except Exception:
        return None


def compute_disease_weights(features):
    """
    Given color features extracted from the image, return weighted
    probabilities for each disease class. The weights are designed
    to respond realistically to plant image characteristics.
    """
    if features is None:
        # Fallback to balanced default weights
        return {
            'healthy': 30, 'early_blight': 10, 'late_blight': 8,
            'powdery_mildew': 10, 'leaf_rust': 10, 'bacterial_blight': 7,
            'root_rot': 5, 'anthracnose': 8, 'mosaic_virus': 7, 'nutrient_deficiency': 5,
        }

    gr = features['green_ratio']
    yr = features['yellow_ratio']
    br = features['brown_ratio']
    or_ = features['orange_ratio']
    wr = features['white_ratio']
    dr = features['dark_ratio']
    brightness = features['avg_brightness']

    # Base weights — start neutral, then adjust by image features
    w = {
        'healthy':              5,
        'early_blight':         5,
        'late_blight':          5,
        'powdery_mildew':       5,
        'leaf_rust':            5,
        'bacterial_blight':     5,
        'root_rot':             5,
        'anthracnose':          5,
        'mosaic_virus':         5,
        'nutrient_deficiency':  5,
    }

    # === Healthy signals ===
    # Dominant green, low brown/dark/yellow
    if gr > 0.45:
        w['healthy'] += int(gr * 60)
    if gr > 0.55:
        w['healthy'] += 20
    # Penalise healthy if many stress signals
    w['healthy'] -= int((yr + br + dr) * 40)

    # === Yellow/chlorosis signals → nutrient deficiency, mosaic, bacterial blight ===
    if yr > 0.10:
        w['nutrient_deficiency'] += int(yr * 80)
        w['mosaic_virus']        += int(yr * 50)
        w['bacterial_blight']    += int(yr * 30)
    if yr > 0.20:
        w['nutrient_deficiency'] += 25
        w['mosaic_virus']        += 15

    # === Brown/necrotic signals → blights, anthracnose, root rot ===
    if br > 0.08:
        w['early_blight']    += int(br * 90)
        w['anthracnose']     += int(br * 60)
        w['bacterial_blight'] += int(br * 40)
    if br > 0.15:
        w['late_blight']  += int(br * 70)
        w['root_rot']     += int(br * 40)

    # === Orange spots → leaf rust ===
    if or_ > 0.05:
        w['leaf_rust']    += int(or_ * 120)
        w['anthracnose']  += int(or_ * 40)
    if or_ > 0.12:
        w['early_blight'] += int(or_ * 50)

    # === White/gray → powdery mildew ===
    if wr > 0.08:
        w['powdery_mildew'] += int(wr * 100)
    if wr + features['gray_ratio'] > 0.15:
        w['powdery_mildew'] += 20

    # === Dark pixels → late blight, root rot, bacterial blight ===
    if dr > 0.10:
        w['late_blight']      += int(dr * 60)
        w['root_rot']         += int(dr * 50)
        w['bacterial_blight'] += int(dr * 40)
    if dr > 0.20:
        w['anthracnose']  += int(dr * 30)

    # === Very dark / low brightness → severe disease ===
    if brightness < 70:
        w['root_rot']     += 25
        w['late_blight']  += 20
        w['healthy']      -= 20

    # Ensure no negative weights
    for k in w:
        w[k] = max(1, w[k])

    return w


def smart_ai_predict(image_path=None):
    """
    Legacy compatibility shim. Color heuristics are not a trained disease
    model and must not be presented as an image diagnosis.
    """
    return {
        'success': False,
        'name': 'Image diagnosis unavailable',
        'key': 'unavailable',
        'confidence': None,
        'severity': 'unclear',
        'is_healthy': 0,
        'description': (
            'No trained local image model is configured. Add Gemini credentials '
            'to request an image-based assessment.'
        ),
        'treatment': 'No image-based treatment recommendation is available.',
        'prevention': 'Use general plant-care guidance until an image assessment is available.',
        'alternatives': [],
        'image_signals': [],
        'analysis_method': 'unavailable'
    }


# Keep legacy name as alias
def mock_ai_predict():
    return smart_ai_predict(image_path=None)
