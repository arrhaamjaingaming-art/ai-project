import os
import hmac
import secrets
from flask import Flask, abort, jsonify, redirect, render_template, request, session, url_for
from models.database import init_db, get_db
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.scanner import scanner_bp
from routes.plants import plants_bp
from routes.history import history_bp
from routes.reports import reports_bp
from routes.settings_route import settings_bp
from routes.ai import ai_bp
from routes.onboarding import onboarding_bp
from routes.recommendations import recommendations_bp
from routes.weather import weather_bp
from routes.reminders import reminders_bp
from routes.media import media_bp
from routes.about import about_bp
from utils.security import csrf_token
from utils.translations import translate, LANGUAGE_NAMES

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY') or os.environ.get('SESSION_SECRET')
if not app.secret_key:
    # Local installs get one persistent, private key rather than a source-code
    # default. Hosted installs should set SECRET_KEY or SESSION_SECRET.
    os.makedirs(app.instance_path, exist_ok=True)
    secret_path = os.path.join(app.instance_path, 'session_secret')
    if os.path.exists(secret_path):
        with open(secret_path, 'r', encoding='utf-8') as secret_file:
            app.secret_key = secret_file.read().strip()
    else:
        app.secret_key = secrets.token_urlsafe(48)
        flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
        fd = os.open(secret_path, flags, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as secret_file:
            secret_file.write(app.secret_key)

app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = (
    os.environ.get('SESSION_COOKIE_SECURE', '').lower() in ('1', 'true', 'yes')
    or bool(os.environ.get('REPLIT_DOMAINS'))
)
app.config['PERMANENT_SESSION_LIFETIME'] = 60 * 60 * 24 * 30

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

init_db()

app.register_blueprint(auth_bp)
app.register_blueprint(onboarding_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(scanner_bp)
app.register_blueprint(plants_bp)
app.register_blueprint(history_bp)
app.register_blueprint(reports_bp)
app.register_blueprint(settings_bp)
app.register_blueprint(ai_bp)
app.register_blueprint(recommendations_bp)
app.register_blueprint(weather_bp)
app.register_blueprint(reminders_bp)
app.register_blueprint(about_bp)
app.register_blueprint(media_bp)


def _is_json_request():
    return request.path.startswith('/api/') or request.path.startswith('/ai/api/')


@app.before_request
def enforce_csrf():
    if request.method not in ('POST', 'PUT', 'PATCH', 'DELETE'):
        return None
    expected = session.get('_csrf_token', '')
    supplied = request.headers.get('X-CSRF-Token') or request.form.get('csrf_token', '')
    if not expected or not supplied or not hmac.compare_digest(expected, supplied):
        if _is_json_request() or request.is_json:
            return jsonify({'success': False, 'error': 'Your session expired. Refresh and try again.'}), 400
        abort(400)
    return None


@app.context_processor
def inject_template_context():
    user_id = session.get('user_id', 1)
    name = session.get('full_name') or session.get('username') or 'Agri Farmer'
    language = session.get('language', 'en')
    notification_reminders = []
    try:
        db = get_db()
        notification_reminders = db.execute(
            """SELECT id, title, reminder_date
               FROM reminders
               WHERE user_id = ? AND is_completed = 0
               ORDER BY reminder_date ASC LIMIT 4""",
            (user_id,)
        ).fetchall()
        db.close()
    except Exception:
        app.logger.warning('Could not load reminder notifications')
    return {
        'csrf_token': csrf_token,
        't': lambda message: translate(language, message),
        'language_name': LANGUAGE_NAMES.get(language, 'English'),
        'is_rtl': language == 'ur',
        'notification_reminders': notification_reminders,
        'current_user': {
            'id': user_id,
            'name': name,
            'email': session.get('email', ''),
            'mode': session.get('user_mode', 'farmer'),
            'is_guest': user_id == 1
        }
    }


@app.route('/')
def home():
    db = None
    try:
        db = get_db()
        onboarding = db.execute(
            'SELECT onboarding_completed FROM users WHERE id = ?', (session.get('user_id', 1),)
        ).fetchone()
        if onboarding and not onboarding['onboarding_completed']:
            return redirect(url_for('onboarding.index'))
    finally:
        if db:
            db.close()
    return redirect(url_for('dashboard.index'))


@app.errorhandler(404)
def not_found(e):
    return render_template('404.html'), 404


@app.errorhandler(500)
def server_error(e):
    app.logger.exception('Unhandled application error')
    if _is_json_request():
        return jsonify({'success': False, 'error': 'The request could not be completed.'}), 500
    return render_template('404.html', error='The request could not be completed. Please try again.'), 500


@app.errorhandler(400)
def bad_request(e):
    if _is_json_request():
        return jsonify({'success': False, 'error': 'The request could not be verified. Refresh and try again.'}), 400
    return render_template('404.html', error='The request could not be verified. Refresh and try again.'), 400


@app.errorhandler(413)
def payload_too_large(e):
    message = 'Image is too large. Please choose a file smaller than 16 MB.'
    if _is_json_request():
        return jsonify({'success': False, 'error': message}), 413
    return render_template('404.html', error=message), 413


if __name__ == '__main__':
    app.run(
        host='0.0.0.0',
        port=int(os.environ.get('PORT', '8080')),
        debug=False
    )
