import sqlite3
import os

APP_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_PATH = os.environ.get(
    'AGRI_DATABASE_PATH',
    os.path.join(APP_ROOT, 'database', 'agri_defence.db')
)

GUEST_USER_ID = 1


def get_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 10000")
    return conn


def _ensure_column(conn, table, column, definition):
    """Add a column only when it is missing; never replace existing data."""
    columns = [
        row['name']
        for row in conn.execute('PRAGMA table_info({})'.format(table)).fetchall()
    ]
    if column not in columns:
        conn.execute(
            'ALTER TABLE {} ADD COLUMN {} {}'.format(table, column, definition)
        )


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = get_db()
    try:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            full_name TEXT,
            language TEXT DEFAULT 'en',
            theme TEXT DEFAULT 'light',
            user_mode TEXT DEFAULT 'farmer',
            location TEXT,
            onboarding_completed INTEGER DEFAULT 0,
            notifications_email INTEGER DEFAULT 1,
            notifications_push INTEGER DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS plants (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL DEFAULT 1,
            name TEXT NOT NULL,
            species TEXT,
            location TEXT,
            planted_date TEXT,
            health_status TEXT DEFAULT 'healthy',
            notes TEXT,
            observations TEXT,
            image_path TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL DEFAULT 1,
            plant_id INTEGER,
            plant_name TEXT,
            image_path TEXT NOT NULL,
            disease_name TEXT,
            disease_key TEXT,
            confidence REAL,
            severity TEXT,
            treatment TEXT,
            prevention TEXT,
            description TEXT,
            is_healthy INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL DEFAULT 1,
            plant_id INTEGER,
            title TEXT NOT NULL,
            reminder_type TEXT DEFAULT 'water',
            reminder_date TEXT,
            is_completed INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE TABLE IF NOT EXISTS activities (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL DEFAULT 1,
            action TEXT NOT NULL,
            description TEXT,
            icon TEXT DEFAULT 'fa-leaf',
            color TEXT DEFAULT 'green',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );

        CREATE INDEX IF NOT EXISTS idx_plants_user_created
            ON plants(user_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_scans_user_created
            ON scans(user_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_reminders_user_date
            ON reminders(user_id, reminder_date, is_completed);
        """)

        # Migrate older databases in place. Existing guest records and users are
        # left untouched; each added field has a safe default.
        _ensure_column(conn, 'users', 'user_mode', "TEXT DEFAULT 'farmer'")
        _ensure_column(conn, 'users', 'location', 'TEXT')
        _ensure_column(conn, 'users', 'onboarding_completed', 'INTEGER DEFAULT 0')
        _ensure_column(conn, 'users', 'notifications_email', 'INTEGER DEFAULT 1')
        _ensure_column(conn, 'users', 'notifications_push', 'INTEGER DEFAULT 1')
        _ensure_column(conn, 'plants', 'observations', 'TEXT')

        # Ensure guest user (id=1) always exists — no sign-in required.
        existing_guest = conn.execute(
            'SELECT id FROM users WHERE id = ?', (GUEST_USER_ID,)
        ).fetchone()
        if not existing_guest:
            conn.execute(
                """INSERT INTO users (id, username, email, password, full_name)
                   VALUES (?, 'farmer', 'farmer@agridefence.local', 'no-auth', 'Agri Farmer')""",
                (GUEST_USER_ID,)
            )

        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
